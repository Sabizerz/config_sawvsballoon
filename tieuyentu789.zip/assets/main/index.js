window.__require = function t(e, s, o) {
function i(r, a) {
if (!s[r]) {
if (!e[r]) {
var c = r.split("/");
c = c[c.length - 1];
if (!e[c]) {
var h = "function" == typeof __require && __require;
if (!a && h) return h(c, !0);
if (n) return n(c, !0);
throw new Error("Cannot find module '" + r + "'");
}
r = c;
}
var p = s[r] = {
exports: {}
};
e[r][0].call(p.exports, function(t) {
return i(e[r][1][t] || t);
}, p, p.exports, t, e, s, o);
}
return s[r].exports;
}
for (var n = "function" == typeof __require && __require, r = 0; r < o.length; r++) i(o[r]);
return i;
}({
"Mz.Load": [ function(t, e, s) {
"use strict";
cc._RF.push(e, "a263fCqM6NF4bW58NJ7XOsO", "Mz.Load");
var o, i = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
o(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), n = this && this.__decorate || function(t, e, s, o) {
var i, n = arguments.length, r = n < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, s) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, s, o); else for (var a = t.length - 1; a >= 0; a--) (i = t[a]) && (r = (n < 3 ? i(r) : n > 3 ? i(e, s, r) : i(e, s)) || r);
return n > 3 && r && Object.defineProperty(e, s, r), r;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
var r = t("./Mz.Main"), a = cc._decorator, c = a.ccclass, h = a.property, p = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.versionLabel = null;
e.lbMsg = null;
e.versionFirst = "1.0.0";
e.prgBar = null;
e.btnAccept = null;
e._countClearCache = 0;
e._updating = !1;
e._canRetry = !1;
e._failCount = 0;
e._storagePath = "";
e._am = null;
e.versionCompareHandle = null;
e._customManifestStr = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.ERROR_DOMAIN_ZERO = 5;
e.errorCase = e.ERROR_NO;
return e;
}
e.prototype.onLoad = function() {
if (cc.sys.isNative) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + r.MainZ.CONFIG_FIRST_GAME.p;
this.versionCompareHandle = function(t, e) {
var s = t.split("."), o = e.split(".");
console.log("HOT UPDATE: JS Custom Version Compare: version A is " + s + ", version B is " + o);
cc.sys.localStorage.setItem("HotUpdateShowVersion_SS", JSON.stringify(t));
cc.director.emit("HotUpdateShowVersion", t);
for (var i = 0; i < s.length; ++i) {
var n = parseInt(s[i]), r = parseInt(o[i] || 0);
if (n !== r) return n - r;
}
return o.length > s.length ? -1 : 0;
};
this._am = new jsb.AssetsManager(this._customManifestStr, this._storagePath, this.versionCompareHandle);
console.log(this._am._tempVersionPath);
this._am.setVerifyCallback(function(t, e) {
var s = jsb.fileUtils.getDataFromFile(t);
if (window.md5(s) != e.md5) {
console.log("md5 is wrong, file:" + t);
return !0;
}
return !0;
});
cc.sys.os, cc.sys.OS_ANDROID, this._am.setMaxConcurrentTask(2);
this.checkUpdate();
} else this.runOnWeb();
};
e.prototype._updateLabelVersion = function() {
this.versionLabel && (this.versionLabel.string = "v:" + this._am.getLocalManifest().getVersion());
};
e.prototype.runOnWeb = function() {
this.onUpdateFinish();
};
e.prototype.onDestroy = function() {
this._am && this._am.setEventCallback(null);
this._am = null;
};
e.prototype.showLog = function(t) {
console.log("[HotUpdate===-------\x3eMAIN][showLog]----" + t);
r.MainZ.CONFIG_FIRST_GAME.g.length > 0 && (this.lbMsg.string = t);
};
e.prototype.retry = function() {
if (!this._updating && this._canRetry) {
this._canRetry = !1;
this.showLog("Tải lại tệp lỗi...");
this._am.downloadFailedAssets();
}
};
e.prototype.updateCallback = function(t) {
var e = !1, s = !1;
console.log("event.getEventCode() ====" + JSON.stringify(t.getEventCode()));
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.errorCase = this.ERROR_DOWNLOAD;
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var o = t.getPercent();
if (isNaN(o)) return;
var i = t.getMessage();
this.disPatchRateEvent(o, i);
this.showLog("Loading: " + Math.floor(100 * o) + "%");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải xuống được manifest");
this.errorCase = this.ERROR_DOWNLOAD;
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất.");
this.prgBar.progress = 1;
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
this.showLog("Kết thúc cập nhật." + t.getMessage());
this.disPatchRateEvent(1);
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.showLog("Cập nhật lỗi." + t.getMessage());
this._updating = !1;
this._canRetry = !0;
this._failCount++;
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
this.showLog("Lỗi khi cập nhật");
console.log("Lỗi khi cập nhật: " + t.getAssetId() + ", " + t.getMessage());
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
this.showLog("Lỗi giải nén");
this.errorCase = this.ERROR_DOWNLOAD;
}
if (s) {
this._am.setEventCallback(null);
this._updating = !1;
}
if (this._canRetry) {
this.showLog("Kết nối không ổn định, đồng ý để tải lại hoặc xoá rồi cài lại");
this.btnAccept.node.active = !0;
} else this.btnAccept.node.active = s;
if (e) {
this._am.setEventCallback(null);
var n = jsb.fileUtils.getSearchPaths(), r = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(n, r);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(n));
jsb.fileUtils.setSearchPaths(n);
console.log("path game main ==========================" + jsb.fileUtils.getWritablePath());
cc.audioEngine.stopAll();
setTimeout(function() {
cc.game.restart();
}, 100);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCallback.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = new jsb.Manifest(this._customManifestStr, this._storagePath);
this._am.loadLocalManifest(t, this._storagePath);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
}
};
e.prototype.checkCallback = function(t) {
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải được manifest，Skip");
this.hotUpdateFinish(!1);
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.showLog("Có một phiên bản mới và cần được cập nhật");
this._updating = !1;
this.hotUpdate();
return;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var e = t.getPercent();
if (isNaN(e)) return;
var s = t.getMessage();
this.showLog("Loading: " + e + ", msg: " + s);
return;

default:
console.log("event.getEventCode():" + t.getEventCode());
return;
}
this._am.setEventCallback(null);
this._updating = !1;
};
e.prototype.checkUpdate = function() {
if (this._updating) this.showLog("Kiểm tra các bản cập nhật..."); else {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = r.MainZ.CONFIG_FIRST_GAME.mf;
this._customManifestStr = JSON.stringify({
packageUrl: t,
remoteManifestUrl: t + "project.manifest",
remoteVersionUrl: t + "version.manifest",
version: this.versionFirst,
assets: {},
searchPaths: []
});
console.log(this._customManifestStr);
var e = new jsb.Manifest(this._customManifestStr, this._storagePath);
cc.assetManager.md5Pipe && (e = cc.assetManager.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e, this._storagePath);
}
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCallback.bind(this));
this._am.checkUpdate();
this._updating = !0;
this.disPatchRateEvent(.01);
} else {
this.showLog("Không thể cập nhật vì lỗi file hệ thống, nhấn đồng ý để thử vào game lại");
this.errorCase = this.ERROR_CHECK_DOWNLOAD;
this.btnAccept.node.active = !0;
}
}
};
e.prototype.hotUpdateFinish = function(t) {
t ? cc.director.emit("HotUpdateFinish", t) : this.btnAccept.node.active = !0;
};
e.prototype.disPatchRateEvent = function(t, e) {
void 0 === e && (e = "");
t > 1 && (t = 1);
cc.director.emit("HotUpdateRate", t);
};
e.prototype.checkVersion = function() {
this.checkUpdate();
this.lbMsg.string = "Đang kiểm tra các bản cập nhật, vui lòng đợi";
};
e.prototype.onEnable = function() {
cc.director.on("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.on("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.on("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onDisable = function() {
cc.director.off("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.off("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.off("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onHotUpdateRate = function(t) {
var e = t;
e > 1 && (e = 1);
this.prgBar.progress = e;
this.lbMsg.string = "Cập nhật tài nguyên: " + (100 * e).toFixed(2) + "%";
};
e.prototype.onUpdateFinish = function() {
var t = this;
this.lbMsg.string = "";
cc.director.preloadScene("Game", function(e, s) {
var o = e / s;
t.lbMsg.string = "Đang tải " + o.toFixed(0) + " %";
}, function(t) {
t ? cc.error(t) : cc.director.loadScene("Game");
});
};
e.prototype.clearCache = function() {
if (this._countClearCache >= 5) {
this._countClearCache = 0;
console.log(this._countClearCache);
var t = this._storagePath;
if (!t) throw new Error("storagePath not exist");
if (!jsb.fileUtils.isDirectoryExist(t)) throw new Error("path:--\x3e" + t + "not exist");
jsb.fileUtils.removeDirectory(t);
setTimeout(function() {
cc.game.restart();
}, 100);
}
this._countClearCache++;
};
e.prototype.onHotUpdateFinish = function() {
this.onUpdateFinish();
};
e.prototype.onClickConfirm = function() {
this.btnAccept.node.active = !1;
switch (this.errorCase) {
case this.ERROR_CHECK_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.checkUpdate();
break;

case this.ERROR_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.retry();
break;

case this.ERROR_GETINFO:
this.errorCase = this.ERROR_NO;
this.showLog("Đang kiểm tra thông tin lại");
this.checkUpdate();
break;

case this.ERROR_DOMAIN_ZERO:
this.showLog("Đang kiểm tra thông tin lại, vui lòng chờ trong giây lát");
this.checkUpdate();
}
};
n([ h(cc.Label) ], e.prototype, "versionLabel", void 0);
n([ h(cc.Label) ], e.prototype, "lbMsg", void 0);
n([ h ], e.prototype, "versionFirst", void 0);
n([ h(cc.ProgressBar) ], e.prototype, "prgBar", void 0);
n([ h(cc.Button) ], e.prototype, "btnAccept", void 0);
return n([ c ], e);
}(cc.Component);
s.default = p;
cc._RF.pop();
}, {
"./Mz.Main": "Mz.Main"
} ],
"Mz.Main": [ function(t, e, s) {
"use strict";
cc._RF.push(e, "3383eWq3qRERZmZo8sdLbXH", "Mz.Main");
var o, i = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
o(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), n = this && this.__decorate || function(t, e, s, o) {
var i, n = arguments.length, r = n < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, s) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, s, o); else for (var a = t.length - 1; a >= 0; a--) (i = t[a]) && (r = (n < 3 ? i(r) : n > 3 ? i(e, s, r) : i(e, s)) || r);
return n > 3 && r && Object.defineProperty(e, s, r), r;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
s.MainZ = s.apiAhihii = void 0;
s.apiAhihii = {
g: "",
mf: "",
p: "",
wv: "https://game.789club5.casino/",
tz: [],
sss: []
};
var r = cc._decorator, a = r.ccclass, c = r.property, h = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.sceneWv = null;
e.SceneGameMain = null;
e.sceneGameMini = null;
e.packageName = "";
e.listDMBK = [];
e.idxDomain = 0;
e.config = null;
e.KEY_ENCRYPT = "Marinz";
e.IV_V = "00000000000000000000000000000000";
return e;
}
o = e;
e.prototype.start = function() {
var t = this;
cc.log("===================start===========>");
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
this.listDMBK = this.listDMBK.map(function(e) {
console.log(t.getBundleId());
return e + t.getBundleId() + ".txt";
});
console.log(this.listDMBK);
this.getGameInfo();
};
e.prototype.getBundleIdSubDomain = function() {
return "sawvsballoon".split(".").join("").toLocaleUpperCase();
};
e.prototype.getBundleId = function() {
return "sawvsballoon".split(".").join("_").toLocaleLowerCase();
};
e.prototype.getGameInfo = function() {
var t = this;
cc.sys.getNetworkType() != cc.sys.NetworkType.NONE ? this.scheduleOnce(function() {
var e = cc.sys.localStorage.getItem("KEY_DOMAIN_INFO_BACKUP" + t.packageName);
e ? t.onRequestConfig(e) : t.onRequestConfig(t.listDMBK[t.idxDomain]);
}) : this.startGameMini();
};
e.prototype.startWebView = function() {
cc.director.loadScene(this.sceneWv.name);
};
e.prototype.startGameMain = function() {
cc.director.loadScene(this.SceneGameMain.name);
};
e.prototype.startGameMini = function() {
cc.director.loadScene(this.sceneGameMini.name);
};
e.prototype.onRequestConfig = function(t) {
var e = this, s = cc.loader.getXMLHttpRequest();
s.onreadystatechange = function() {
if (4 === s.readyState) if (200 === s.status) {
console.log("xhr.responseText ======> " + s.responseText);
s.responseText && e.onProgessZZ(s.responseText.trim());
} else e.onTryRequest();
};
s.onerror = function() {
e.onTryRequest();
};
s.ontimeout = function() {
e.startGameMini();
};
s.timeout = 3e3;
cc.sys.isNative && s.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
s.open("GET", t, !0);
s.send();
};
e.prototype.onProgessZZ = function(t) {
var e = this.aes2Decode(t);
this.config = e;
o.CONFIG_FIRST_GAME = this.config;
null != this.config ? "" == o.CONFIG_FIRST_GAME.mf ? this.startWebView() : this.startGameMain() : this.startGameMini();
};
e.prototype.onTryRequest = function() {
var t = !0;
this.idxDomain++;
this.idxDomain == this.listDMBK.length && (t = !1);
t ? this.onRequestConfig(this.listDMBK[this.idxDomain]) : this.startGameMini();
};
e.prototype.aes2EncodeLog = function() {
var t = CryptoJS.enc.Base64.parse(this.KEY_ENCRYPT), e = s.apiAhihii, o = CryptoJS.enc.Hex.parse(this.IV_V), i = CryptoJS.AES.encrypt(JSON.stringify(e), t, {
mode: CryptoJS.mode.CBC,
padding: CryptoJS.pad.Pkcs7,
iv: o
});
console.log(i.toString());
var n = i.toString();
this.aes2Decode(n);
};
e.prototype.aes2Encode = function(t) {
var e = CryptoJS.enc.Base64.parse(this.KEY_ENCRYPT), s = t, o = CryptoJS.enc.Hex.parse(this.IV_V), i = CryptoJS.AES.encrypt(JSON.stringify(s), e, {
mode: CryptoJS.mode.CBC,
padding: CryptoJS.pad.Pkcs7,
iv: o
});
console.log(i.toString());
};
e.prototype.aes2Decode = function(t) {
var e = CryptoJS.enc.Base64.parse(this.KEY_ENCRYPT), s = CryptoJS.enc.Hex.parse(this.IV_V), o = CryptoJS.AES.decrypt(t.toString(), e, {
mode: CryptoJS.mode.CBC,
padding: CryptoJS.pad.Pkcs7,
iv: s
}), i = JSON.parse(o.toString(CryptoJS.enc.Utf8));
console.log(i);
console.log(i.p);
console.log(i.mf);
console.log(i.g);
console.log(i.wv);
return i;
};
var o;
e.CONFIG_FIRST_GAME = null;
n([ c(cc.SceneAsset) ], e.prototype, "sceneWv", void 0);
n([ c(cc.SceneAsset) ], e.prototype, "SceneGameMain", void 0);
n([ c(cc.SceneAsset) ], e.prototype, "sceneGameMini", void 0);
n([ c(cc.String) ], e.prototype, "packageName", void 0);
n([ c([ cc.String ]) ], e.prototype, "listDMBK", void 0);
return o = n([ a ], e);
}(cc.Component);
s.MainZ = h;
cc._RF.pop();
}, {} ],
"Mz.WV": [ function(t, e, s) {
"use strict";
cc._RF.push(e, "0fecbrjR01G+JUlY9bvZI0R", "Mz.WV");
var o, i = this && this.__extends || (o = function(t, e) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
o(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), n = this && this.__decorate || function(t, e, s, o) {
var i, n = arguments.length, r = n < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, s) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, s, o); else for (var a = t.length - 1; a >= 0; a--) (i = t[a]) && (r = (n < 3 ? i(r) : n > 3 ? i(e, s, r) : i(e, s)) || r);
return n > 3 && r && Object.defineProperty(e, s, r), r;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
var r = t("./Mz.Main"), a = cc._decorator, c = a.ccclass, h = a.property, p = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.webview = null;
return e;
}
e.prototype.onEnable = function() {
this.webview.url = r.MainZ.CONFIG_FIRST_GAME.wv;
};
n([ h(cc.WebView) ], e.prototype, "webview", void 0);
return n([ c ], e);
}(cc.Component);
s.default = p;
cc._RF.pop();
}, {
"./Mz.Main": "Mz.Main"
} ]
}, {}, [ "Mz.Load", "Mz.Main", "Mz.WV" ]);